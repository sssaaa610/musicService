package com.example.musicservice;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

public class MyMusicService extends Service {
    private MediaPlayer mediaPlayer;
    private final IBinder binder = new LocalBinder();
    private static final String ACTION_PLAY = "play";
    private static final String ACTION_STOP = "stop";
    private static final String ACTION_PAUSE = "pause";

    public class LocalBinder extends Binder {
        MyMusicService getService() {
            return MyMusicService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        initializeMediaPlayer();
    }

    private void initializeMediaPlayer() {
        try {
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(this, R.raw.newyear);
                mediaPlayer.setLooping(false); // 设置不循环播放

                // 添加播放完成监听器
                mediaPlayer.setOnCompletionListener(mp -> {
                    Toast.makeText(getApplicationContext(), "播放完成", Toast.LENGTH_SHORT).show();
                    // 可选：通知活动更新 UI 状态
                });
            }
        } catch (Exception e) {
            Toast.makeText(this, "初始化播放器失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getStringExtra("action") == null) {
            return START_NOT_STICKY;
        }

        String action = intent.getStringExtra("action");
        try {
            switch (action) {
                case ACTION_PLAY:
                    playMusic();
                    break;
                case ACTION_STOP:
                    stopMusic();
                    break;
                case ACTION_PAUSE:
                    pauseMusic();
                    break;
            }
        } catch (Exception e) {
            Toast.makeText(this, "操作失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        return START_NOT_STICKY;
    }

    private void playMusic() {
        if (mediaPlayer == null) {
            initializeMediaPlayer();
        }
        if (!mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    private void stopMusic() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void pauseMusic() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    // 添加获取当前进度的方法
    public int getCurrentProgress() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            return mediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    // 添加获取总时长的方法
    public int getDuration() {
        if (mediaPlayer != null) {
            return mediaPlayer.getDuration();
        }
        return 0;
    }

    // 添加跳转到指定位置的方法
    public void seekTo(int position) {
        if (mediaPlayer != null) {
            mediaPlayer.seekTo(position);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            stopMusic();
        }
    }
}
