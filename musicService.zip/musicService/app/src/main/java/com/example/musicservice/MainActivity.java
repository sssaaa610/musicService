package com.example.musicservice;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView tv_1;
    private SeekBar seekBar;
    private boolean isPlaying = false;
    private static final String ACTION_PLAY = "play";
    private static final String ACTION_STOP = "stop";
    private static final String ACTION_PAUSE = "pause";

    private MyMusicService musicService;
    private boolean isBound = false;
    private Handler handler = new Handler();

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MyMusicService.LocalBinder binder = (MyMusicService.LocalBinder) service;
            musicService = binder.getService();
            isBound = true;
            // 初始化 SeekBar 的最大值
            int duration = musicService.getDuration();
            seekBar.setMax(duration);
            updateSeekBar();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    private Runnable updateSeekRunnable = new Runnable() {
        @Override
        public void run() {
            if (isBound && musicService != null && isPlaying) {
                int currentPosition = musicService.getCurrentProgress();
                seekBar.setProgress(currentPosition);
            }
            handler.postDelayed(this, 1000); // 每秒更新一次
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // 确保引用了正确的布局文件

        tv_1 = findViewById(R.id.tv_1);
        seekBar = findViewById(R.id.seekBar);
        updatePlayStatus("停止");

        // 设置 SeekBar 监听器，以便用户可以拖动 SeekBar 来调整播放位置
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // 如果是用户拖动 SeekBar，更新播放位置
                if (fromUser && isBound && musicService != null) {
                    musicService.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // 用户开始拖动 SeekBar，可选操作
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // 用户停止拖动 SeekBar，可选操作
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        // 绑定服务
        Intent intent = new Intent(this, MyMusicService.class);
        bindService(intent, serviceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isBound) {
            unbindService(serviceConnection);
            isBound = false;
        }
        handler.removeCallbacks(updateSeekRunnable);
    }

    private void updatePlayStatus(String status) {
        if (tv_1 != null) {
            tv_1.setText(String.format("播放状态：%s", status));
        }
    }

    private void sendMusicCommand(String action) {
        try {
            Intent intent = new Intent(this, MyMusicService.class);
            intent.putExtra("action", action);
            startService(intent);
        } catch (Exception e) {
            Toast.makeText(this, "操作失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void play_onclick(View view) {
        sendMusicCommand(ACTION_PLAY);
        isPlaying = true;
        updatePlayStatus("正在播放");
        handler.post(updateSeekRunnable); // 开始更新 SeekBar
    }

    public void stop_onclick(View view) {
        sendMusicCommand(ACTION_STOP);
        isPlaying = false;
        updatePlayStatus("停止播放");
        seekBar.setProgress(0); // 重置 SeekBar
        handler.removeCallbacks(updateSeekRunnable); // 停止更新
    }

    public void pause_onclick(View view) {
        sendMusicCommand(ACTION_PAUSE);
        isPlaying = false;
        updatePlayStatus("暂停播放");
        handler.removeCallbacks(updateSeekRunnable); // 停止更新
    }

    public void exit_onclick(View view) {
        if (isPlaying) {
            stop_onclick(view);
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isBound) {
            unbindService(serviceConnection);
            isBound = false;
        }
        if (isPlaying) {
            sendMusicCommand(ACTION_STOP);
        }
    }

    private void updateSeekBar() {
        if (isBound && musicService != null) {
            int duration = musicService.getDuration();
            seekBar.setMax(duration);
        }
    }
}
